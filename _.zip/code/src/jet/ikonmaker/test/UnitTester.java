package jet.ikonmaker.test;

import org.grandtestauto.*;
import org.grandtestauto.distributed.*;

@SimpleGrade( grade = 5 )
public final class UnitTester extends CoverageUnitTester {

    public UnitTester( final GrandTestAuto gta ) {
        super( gta );
    }
}