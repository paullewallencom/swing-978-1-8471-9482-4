package jet.webservice.jaxws.test;

import org.grandtestauto.*;

/**
 * Since the jaxws package is generated, it does not
 * need unit testing. This class just returns true
 * for the unit tests.
 */
public class UnitTester implements UnitTesterIF {
    public boolean runTests() {
        return true;
    }
}
