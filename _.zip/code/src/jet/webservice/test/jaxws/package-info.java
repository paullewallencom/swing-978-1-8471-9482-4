@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice.jet/")
package jet.webservice.test.jaxws;
