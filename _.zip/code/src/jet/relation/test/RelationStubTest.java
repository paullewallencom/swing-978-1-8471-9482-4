package jet.relation.test;

import jet.relation.*;

public class RelationStubTest {

    //Dummy tests for all methods, as this is only a demo class.
    public boolean addTest() {
        return true;
    }

    public boolean removeTest() {
        return true;
    }

    private Relation<String, String> r() {
        return new Relation<String, String>();
    }

    public boolean constructorTest() {
        return true;
    }

    public boolean sizeTest() {
        return true;
    }

    public boolean domainTest() {
        return true;
    }

    public boolean rangeTest() {
        return true;
    }

    public boolean inRangeTest() {
        return true;
    }

    public boolean rangeForTest() {
        return true;
    }
}