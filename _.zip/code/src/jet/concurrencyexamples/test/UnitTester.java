package jet.concurrencyexamples.test;

import org.grandtestauto.*;
import org.grandtestauto.distributed.*;

@SimpleGrade( grade = 1 )
public final class UnitTester extends CoverageUnitTester {

    public UnitTester( final GrandTestAuto gta ) {
        super( gta );
    }
}
