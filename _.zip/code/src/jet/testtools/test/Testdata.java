package jet.testtools.test;

public class Testdata {

public static String PATH = System.getProperty( "TestDataRoot" )  + "\\";


}