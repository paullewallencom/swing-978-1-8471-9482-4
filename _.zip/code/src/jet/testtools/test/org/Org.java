package jet.testtools.test.org;

public class Org {

public static String PATH = System.getProperty( "TestDataRoot" )  + "\\org\\";


}