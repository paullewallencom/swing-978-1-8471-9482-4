package jet.testtools.test.org.grandtestauto.ant;

public class Ant {

public static String PATH = System.getProperty( "TestDataRoot" )  + "\\org\\grandtestauto\\ant\\";


}