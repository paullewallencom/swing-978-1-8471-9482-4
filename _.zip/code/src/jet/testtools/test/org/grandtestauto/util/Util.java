package jet.testtools.test.org.grandtestauto.util;

public class Util {

public static String PATH = System.getProperty( "TestDataRoot" )  + "\\org\\grandtestauto\\util\\";

public static final String serr_txt = PATH + "serr.txt";
public static final String sout_txt = PATH + "sout.txt";

}