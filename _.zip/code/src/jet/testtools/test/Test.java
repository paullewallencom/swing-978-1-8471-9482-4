package jet.testtools.test;

public class Test {

public static String PATH = System.getProperty( "TestDataRoot" ) + "jet/testtools/test";


}