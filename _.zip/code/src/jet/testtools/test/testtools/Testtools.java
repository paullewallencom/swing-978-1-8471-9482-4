package jet.testtools.test.testtools;

public class Testtools {

public static String PATH = System.getProperty( "TestDataRoot" )  + "\\testtools\\";

public static final String datafile1_txt = PATH + "datafile1.txt";
public static final String datafile2_txt = PATH + "datafile2.txt";
public static final String input_zip = PATH + "input.zip";
public static final String output_zip = PATH + "output.zip";
public static final String a_24hrs10_txt = PATH + "24hrs10.txt";
public static final String zip4_zip = PATH + "zip4.zip";
public static final String zip1_zip = PATH + "zip1.zip";
public static final String zip2_zip = PATH + "zip2.zip";
public static final String zip3_zip = PATH + "zip3.zip";
public static final String datafile_txt = PATH + "datafile.txt";
public static final String Spreadsheet_xls = PATH + "Spreadsheet.xls";
public static final String Pdf1_pdf = PATH + "Pdf1.pdf";

}