package jet.testtools.test.ikonmaker;

public class Ikonmaker {

public static String PATH = System.getProperty( "TestDataRoot" )  + "\\ikonmaker\\";

public static final String waratah_jpg = PATH + "waratah.jpg";
public static final String RGGR_png = PATH + "RGGR.png";
public static final String Iota_ikon = PATH + "Iota.ikon";
public static final String BirdInBush_JPEG = PATH + "BirdInBush.JPEG";
public static final String BRRB_gif = PATH + "BRRB.gif";
public static final String Red_png = PATH + "Red.png";

}